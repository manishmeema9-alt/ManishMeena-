# 3d-cartoon-viral-studio

Claude skill: idea -> finished 3D cartoon short (1080x1920) with auto-editing, captions, music, thumbnail,
viral title/description/hashtags/hints and automatic QC.

Install: upload this folder as a zip in Claude's Skills settings (zip must contain the folder `3d-cartoon-viral-studio/`).
Use: "Ek 3D cartoon video banao: <idea>" (optionally attach a voice-over file).

Manual run (anywhere with python3 + numpy + opencv + ffmpeg):
    python3 scripts/build_video.py templates/storyboard.example.json --out out --quality draft

Needs: python3, numpy, opencv-python, Pillow (thumbnail text), ffmpeg (with libass). Blender optional.
