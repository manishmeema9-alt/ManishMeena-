---
name: 3d-cartoon-viral-studio
description: Use when the user wants a NEW 3D animated cartoon short (Reels/Shorts/TikTok) made from an idea, with auto-editing, hook, captions, music, thumbnail, viral title/description/hashtags and QC. Trigger on "3D cartoon video", "animation video banao", "cartoon short", "viral cartoon". Not for editing a video the user supplied (use viral-video-editor for that).
---

# 3D Cartoon Viral Studio

Goal: from ONE idea (even one line, Hinglish ok) deliver a finished, ready-to-post vertical 3D cartoon
video plus everything needed to post it. User is usually on a phone: ask nothing unless truly blocked,
assume defaults, deliver complete files.

## What you deliver (always all of these)
1. `final.mp4` - 1080x1920, 9:16, 15-40 s, burned-in captions, music+SFX, -14 LUFS
2. `thumbnail.jpg` - big hook text
3. `metadata.txt` - 5 titles, description, hashtags, keywords/tags, pinned comment, on-screen hints, best time IST
4. `captions.srt` - for YouTube upload
Send with SendUserFile (video first). Then ONE short message in the user's language (Hinglish if they write Hinglish),
with the best title + hashtags pasted inline so they can copy without opening files.

## Files in this skill
- `scripts/build_video.py`   one-command pipeline (render -> edit -> captions -> audio -> export -> QC + auto-fix)
- `scripts/render3d.py`      built-in toon 3D renderer (numpy, no GPU). Characters: blob, bunny, cat, robot
- `scripts/make_audio.py`    synthesized royalty-free music + pop/whoosh SFX (no copyright risk)
- `scripts/qc_check.py`      quality gate (size, fps, duration, audio, loudness, silence, black frames)
- `scripts/metadata.py`      writes metadata.txt (uses the `meta` block you write, fills gaps)
- `scripts/blender_scene.py` optional Blender path (untested; only if `which blender` succeeds AND user wants more realism)
- `templates/storyboard.example.json` copy this, change content
- `references/01-story-and-hooks.md`      read FIRST (story structure, hook formulas, pacing)
- `references/02-3d-pipeline.md`          actions, props, cameras, themes, characters, limits
- `references/03-auto-edit-rules.md`      what auto-editing is applied and how to tune it
- `references/04-viral-metadata.md`       titles, description, hashtags, hints, pinned comment formulas
- `references/05-qc-and-fixes.md`         checklist + what to fix when a check fails

## Workflow
1. **Read** `references/01-story-and-hooks.md`. Turn the idea into a 5-8 scene story (20-35 s total).
   Language of captions = user's language (Hinglish roman by default). Max ~7 words per caption line.
2. **Read** `references/02-3d-pipeline.md`. Write `storyboard.json` (copy the template). Every scene needs:
   `dur`, `caption`, `actors[]` with an `action`, a `cam` move, an `env`, and `props`. Vary env/camera on
   every scene (a visual change at least every 2-3 s). Put the biggest moment at 60-75% of the video and a
   `shake:true` on it. Add `hint` on 2 scenes. Write the full `meta` block using `references/04-viral-metadata.md`.
3. **Run**: `python3 /path/to/scripts/build_video.py storyboard.json --out OUTDIR`
   - Add `--quality hd` for 720x1280 render (slower), `--quality fast` for a quick draft.
   - If the user gave a voice/narration file: add `--voice file.mp3` (auto silence-trim, music ducked, scenes fit voice).
   - Typical time: draft ~1-2 min for 25 s. Run in the foreground; use `timeout` up to 600000 ms.
4. **QC**: the script already runs `qc_check.py` and auto-fixes loudness/size. If any FAIL remains, follow
   `references/05-qc-and-fixes.md`, edit storyboard, rebuild. Look at 2-3 extracted frames
   (`ffmpeg -ss 1 -i final.mp4 -frames:v 1 f.png` then Read it) to confirm characters are in frame, captions readable,
   nothing cut off. Fix and rebuild if not. Do this check every time.
5. **Deliver** the 4 files + short message. Never claim guaranteed virality; say "proven retention techniques lagaye hain".

## Rules
- Defaults, not questions: 9:16, 25-30 s, fun mood, Hinglish, theme day, hero = blob.
- Keep every scene readable: 1-2 characters max, camera dist 7-11 for two characters.
- Burned-in text has NO emoji (renderer cannot draw them); emoji only in metadata.
- Never use copyrighted characters, brand names, real people, or copyrighted music/lyrics. Original characters only.
- Content must be safe for all ages unless user asks otherwise (and then still nothing sexual/graphic/hateful).
- If packages/tools are missing and cannot be installed, work with what exists (numpy+OpenCV+ffmpeg are enough) and
  say plainly what was skipped.
- Be honest about the look: built-in renderer = stylized toon 3D (round characters, clean outlines), not Pixar-level.
  For Pixar-like realism the user needs Blender on a computer; offer `blender_scene.py` as the starting point.
- Never overwrite user files; write into a fresh OUTDIR.
