# 01 - Story, hooks, pacing (read before writing the storyboard)

## The 6-beat short (25-30 s)
| Beat | Time | Job | Example (funny) |
|------|------|-----|-----------------|
| 1 HOOK | 0-3 s | Stop the scroll: question, shock, promise | "Is gem ko chhua toh kya hua?!" |
| 2 SETUP | 3-8 s | Who + what they want (1 sentence) | Jelly ko chamakta gem mila |
| 3 TRIGGER | 8-12 s | Something changes | Usne gem ko haath lagaya |
| 4 CHAOS/TWIST | 12-20 s | Biggest moment (shake + camera move) | BOOM! sab ulta ho gaya |
| 5 PAYOFF | 20-25 s | Funny/emotional resolution | Bunny: "Ye toh magic gem hai!" |
| 6 LOOP/CTA | 25-28 s | Cliffhanger or loop back + follow ask | "Part 2 ke liye FOLLOW karo" |

## Hook formulas (pick one, put it as `hook` text AND make scene 1 visually active)
- Curiosity gap: "Is gem ko chhua toh kya hua?!"
- Shock: "Ye 3D hero sab kuch bhool gaya!"
- Challenge: "99% log ye twist nahi pakad paaye"
- Promise: "Last tak dekho, hasi nahi rukegi"
- Relatable: "Jab monday ko alarm bajta hai... "
Rules: <= 8 words, no greeting, no logo intro, motion in frame 1, first caption starts within 0.3 s.

## Retention tricks (all supported by the pipeline)
- Visual change every 2-3 s: new env, new camera orbit, new action (set per scene).
- Punch zoom + white flash on every cut (automatic, `punch:true`).
- `hint` text on 2 scenes: "End tak dekho", "Wait for it...", "Last mein twist hai".
- Biggest moment gets `shake:true`, `scared`/`celebrate` action, darker env (`night`) for contrast.
- Open loop: tease the payoff in hook, deliver in the last third.
- Loop ending: end on a frame that matches scene 1 (same env/hero pose) so replays feel seamless.
- Total length: 20-35 s is the sweet spot; never over 60 s.

## Story genres that work with simple round 3D characters
Funny mishap, moral/kahani, "what if", friendship/rivalry, scary-but-cute, kids learning (colors/numbers),
mini-lessons ("3 tricks..."), animal comedy, food/object characters, seasonal (Diwali, rain, school).

## Writing captions (Hinglish default)
- 3-7 words per scene caption, spoken-style, one idea per scene.
- Use simple Roman Hinglish: "Usne gem ko haath lagaya". Avoid long Hindi in Devanagari unless asked (font fallback risk).
- No emoji in captions (burned-in), no quotes/braces.
- Numbers as digits ("3 trick"), CAPS only on the key word at the twist.

## Voice-over (optional)
If the user supplies audio: scenes are auto-scaled to the voice length. Write captions to match what is said.
No TTS is bundled; if `espeak-ng`/Piper exists you may generate a robotic voice, otherwise captions+music only.
