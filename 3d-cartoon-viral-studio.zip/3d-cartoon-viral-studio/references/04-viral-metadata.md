# 04 - Viral metadata: title, description, hashtags, hints, comment, timing

Write the `meta` block inside storyboard.json (metadata.py turns it into metadata.txt). Language = user's (Hinglish default).
Emoji ARE allowed here (not in burned-in video text).

## Titles (write 5, first = best)
Formulas (<= 70 chars, keyword + curiosity + 1 emoji):
1. Curiosity: "Is gem ko chhua toh kya hua?! 😱 | 3D Cartoon"
2. Dare: "End tak dekho, hasi nahi rukegi 😂"
3. Number: "3D hero ki 3 galtiyan 🤯"
4. Question: "Kya aap bata sakte ho twist? 👀"
5. Engagement: "Part 2 chahiye? Comment karo 👇"
Put the main keyword (3d cartoon / animation / story topic) in the first 40 chars.

## Description (copy-paste ready)
Structure:
1. Line 1 = hook sentence (shows in preview), 2. 2-3 lines of what happens (include keywords naturally, NO spoilers of the twist),
3. CTA line: "👍 Like 💬 Comment 🔁 Share ➕ Follow for Part 2",
4. 5-10 hashtags at the end. Keep < 500 characters for Reels/Shorts.

## Hashtags (10-14)
Mix: 3 broad (#viral #trending #shorts #reels #fyp) + 4 niche (#3danimation #cartoon #animation #funnycartoon)
+ 3 topic-specific (#magicgem #jellyhero) + 1-2 language (#hindicartoon #hinglish).
Do not use banned/spammy tags or unrelated trending tags.

## Keywords / tags (YouTube Studio tags box)
8-12 phrases people actually search: "3d cartoon hindi", "funny animation shorts", "<topic> story", "cartoon for kids" (only if kids content).

## Pinned comment
Ask a question that needs a 1-word reply + promise: "Aapko kaunsa scene best laga? Comment karo 👇 100 likes par Part 2!"

## On-screen hints (retention text inside the video; no emoji)
"End tak dekho", "Wait for it...", "Last mein twist hai", "Bata sakte ho kya hoga?" Use on 2 scenes only.

## Thumbnail text
2-4 words, ALL CAPS, curiosity: "GEM CHHUA TOH?!", "YE KYA HUA?!". Contrast: yellow text with black outline (automatic).

## Best time to post (India, IST)
12:00-13:30 and 19:00-22:00 daily; weekends 10:00-12:00. Post same video as Reel + Short + Facebook reel on different days.

## Posting checklist (also appended to metadata.txt)
Reply to all comments in first hour, pin comment, post 1/day for 30 days, check retention graph, re-use the best hook formula.

## Safety
No misleading claims, no fake "giveaway" lines, no trademarked character names or brand names in title/tags, no clickbait that the video does not pay off.
