# 02 - 3D pipeline reference (storyboard fields, actions, props, cameras)

## Storyboard JSON (top level)
| Key | Meaning | Default |
|-----|---------|---------|
| title | internal title | - |
| niche | funny / story / kids / horror / moral / tech / gaming | default |
| lang | hinglish / hindi / english | hinglish |
| fps | 24 or 30 | 30 |
| bpm | music tempo 90-130 | 110 |
| mood | fun / hype / calm / spooky | fun |
| theme | default env for scenes | day |
| hook | big yellow text first ~2.8 s (no emoji rendered) | title |
| thumbnail_text | text on thumbnail (<= 4 words) | hook |
| end_card | CTA text, auto-adds a 2.4 s end scene | none |
| characters | `{id: {style, color, scale}}` | one orange blob |
| scenes | list (below) | required |
| meta | titles/description/hashtags/... (see 04) | auto-filled |

## Scene fields
`dur` (s) - `caption` - `hint` - `env` - `cam` - `actors[]` - `props[]` - `punch` (default true) - `shake` - `thumb` (use this frame for thumbnail)

### actors[]
`{"id":"hero","action":"dance","x":-1.2,"z":0,"x1":0.4,"face":0.0}`
- x / z : position (x -3..3 visible, z 0 = center, negative = farther)
- x1 : walk/sneak end x
- face : yaw radians (0 = facing camera, +left/-right turn)
- For two characters use x = -1.2 and +1.2, camera dist >= 8.

### Actions (all procedural, loop-safe)
idle, bounce/jump, walk, sneak, wave, dance, scared, spin, celebrate, sad, talk, point

### Characters
style: `blob` (round hero), `bunny` (ears), `cat` (small ears), `robot` (antenna, boxy-cute).
color: any hex. scale: 0.6-1.4. Give each character a distinct color + style.

### Props (type -> fields)
ball (bounce:true) - tree - cloud - gem (floating, glowing) - hill (big background mound, size 2) - box (stack)
Always include a `hill` or `tree` for depth in outdoor scenes.

### Environments (env)
day, sunset, night, candy, space, snow, desert
Match mood: scary = night/space, happy = day/candy, emotional = sunset.

### Camera (`cam`)
`{"orbit":[a0,a1],"dist":[d0,d1],"height":[h0,h1],"target":[x,y,z],"fov":40}`
- orbit degrees around target (0 = front). Move 10-25 degrees per scene for parallax.
- dist: 6-7 close-up, 8-10 two characters, 11+ wide.
- Push-in (dist decreasing) = tension; pull-out (increasing) = reveal; low height (1.5) = hero shot.

## Quality / speed
| --quality | render res | note |
|-----------|-----------|------|
| fast | 432x768 @24 | ~1 min for 17 s, preview |
| draft | 540x960 | default, good for posting |
| hd | 720x1280 | sharper, ~2x slower |
Final export is always upscaled to 1080x1920.

## Limits (be honest with the user)
- Stylized toon look made of rounded shapes; not photoreal / Pixar-level.
- No lip-sync to real speech (mouth flaps during `talk`).
- Max ~3 characters per scene for performance and readability.

## Optional Blender path
Only if `which blender` works: `blender -b -P scripts/blender_scene.py -- storyboard.json OUT`, then encode frames with
`ffmpeg -framerate 30 -i OUT/frames/%05d.png -c:v libx264 -pix_fmt yuv420p silent.mp4` and reuse captions/audio steps of build_video.py.
That script is a starting point and was not tested in the authoring sandbox.
