# 05 - QC and fixes ("kamiyan" ko pakadna aur theek karna)

`build_video.py` runs `qc_check.py` automatically. Then YOU also review 3 frames visually. Fix every FAIL before delivering.

## Automatic checks
| Check | Pass | If FAIL |
|-------|------|---------|
| size | exactly 1080x1920 | rebuild (never hand-edit) |
| fps | 24-60 | pass `--fps 30` |
| duration | 12-60 s | add/remove scenes, aim 20-35 s |
| audio present | yes | rerun; check make_audio.py output |
| loudness | -16..-12 LUFS | auto two-pass loudnorm (already tried once) |
| silence | no gap > 1.2 s | lower scene dur / raise music; check voice file |
| black frames | none | a scene has bad camera (target/dist) or env; fix and rebuild |
| file size | < 100 MB | auto re-encode CRF 24 |

## Visual review checklist (extract frames at 1 s, mid, and last 3 s; Read the PNGs)
- [ ] Hook text visible and not cut off, within first 3 s
- [ ] Every character fully in frame (x within -2.5..2.5, camera dist right)
- [ ] Captions readable (contrast ok, <= 3 lines, not covered by character faces)
- [ ] Scene 1 has motion; peak scene has shake + strong action
- [ ] Env/camera changes at least every 3 s
- [ ] End card CTA visible in last 2.4 s
- [ ] Thumbnail text correct and legible

## Typical problems -> fixes
| Problem | Fix |
|---------|-----|
| Character cut at screen edge | reduce |x|, raise `cam.dist`, set `target` x to the group center |
| Character too small | lower `cam.dist` (6.5-8) |
| Two characters overlap | x = -1.3 and +1.3, different `face` |
| Floor/sky looks flat | add `hill`, `tree`, `cloud` props; use a contrasting `env` |
| Boring middle | add `shake`, change `env`, new action, shorten scene |
| Caption too long | split into two scenes or trim to <= 6 words |
| Emoji missing in video | expected; emoji only in metadata |
| Render too slow | `--quality fast`, or fewer props/characters, shorter total |
| ffmpeg `ass` filter error | run from OUTDIR (script does this); check captions.ass has no `{}` in text |
| Voice too quiet/loud | already normalized; check source file is not clipped |

## Final gate before sending
QC PASSED + 3 frames reviewed + metadata.txt exists + thumbnail.jpg exists. If a fix is impossible, say plainly what is missing.
