# 03 - Auto-edit rules (applied automatically by build_video.py)

| Technique | Where | Tune with |
|-----------|-------|-----------|
| Hook text pop-in (yellow, top) 0-2.8 s | captions.ass style Hook | `hook` |
| Word-by-word captions, 3 words per line, active word yellow + pop | style Cap, lower-middle (safe from UI) | `caption` per scene |
| Retention hint pill | style Hint | `hint` per scene |
| Punch zoom 116% -> 100% on every cut | compose() | `punch:false` to disable |
| White flash 3 frames on cuts | compose() | automatic |
| Impact shake (decays 0.4 s) | compose() + camera | `shake:true` |
| Progress bar (top, yellow) | compose() | automatic |
| Vignette | compose() | automatic |
| Music (synth, bpm-synced) + pop on cut + whoosh before cut | make_audio.py | `bpm`, `mood` |
| Voice: silence trim, high-pass, compress, music ducking | apply_voice + sidechaincompress | `--voice` |
| Loudness -14 LUFS (two-pass auto-fix if off) | ffmpeg loudnorm | automatic |
| End card (CTA) with fade | auto scene | `end_card` |
| Thumbnail (big text over best frame) | make_thumbnail | `thumbnail_text`, `thumb:true` |
| captions.srt | write_srt | automatic |

## Pacing rules the storyboard must obey
- Scene length 2.2-3.5 s (hook scene up to 3.5 s). Never > 4 s without a camera/action change.
- Cut on action: change scene when an action peaks (jump apex, scared start).
- Alternate shot size: wide -> close -> wide. Alternate env colors for contrast.
- First 1.5 s must contain movement and the hook text.
- Last 2.4 s: CTA + loop feel.

## Fixing "feels slow / boring"
1. Shorten every scene by 20%. 2. Add `shake` + `scared`/`celebrate` to the peak. 3. Increase camera orbit range.
4. Change env on alternate scenes. 5. Raise `bpm` to 120+ and set mood `hype`.

## Fixing "captions hard to read"
Shorten caption to <= 6 words; avoid bright env behind (use `night`/`space`); keep hint text short (<= 4 words).
