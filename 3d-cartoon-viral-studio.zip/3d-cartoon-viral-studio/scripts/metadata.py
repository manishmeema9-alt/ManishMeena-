#!/usr/bin/env python3
"""
metadata.py - writes ready-to-paste posting text (titles, description, hashtags,
keywords/tags, pinned comment, thumbnail text, on-screen hints, best time IST).

Best quality: Claude writes the "meta" block inside the storyboard JSON (see
references/04-viral-metadata.md). This script uses that block when present and
fills any missing field with safe rule-based defaults, then saves metadata.txt.

usage: metadata.py storyboard.json OUT_metadata.txt
"""
import json
import sys

NICHE_TAGS = {
    "funny":   ["funny", "comedy", "memes", "laugh", "fun"],
    "story":   ["storytime", "story", "moral", "kahani", "cartoonstory"],
    "kids":    ["kids", "kidscartoon", "nurseryrhymes", "learning", "bachon"],
    "horror":  ["horror", "scary", "spooky", "creepy", "horrorstory"],
    "moral":   ["moralstory", "motivation", "lifelessons", "inspiration"],
    "tech":    ["tech", "ai", "gadgets", "technology", "facts"],
    "gaming":  ["gaming", "gamer", "gameplay", "minecraft", "roblox"],
    "default": ["cartoon", "animation"],
}
CORE = ["3danimation", "cartoon", "animation", "shorts", "reels", "viral", "trending",
        "fyp", "foryou", "explore"]


def uniq(seq):
    seen, out = set(), []
    for s in seq:
        k = s.lower()
        if k not in seen:
            seen.add(k)
            out.append(s)
    return out


def main():
    sb = json.load(open(sys.argv[1], encoding="utf-8"))
    meta = sb.get("meta", {}) or {}
    title = sb.get("title", "Mera 3D Cartoon")
    hook = sb.get("hook", title)
    niche = sb.get("niche", "default")
    lang = sb.get("lang", "hinglish")
    cta = sb.get("end_card", "Follow for Part 2")

    titles = meta.get("titles") or [
        hook,
        f"{title} 😱 End tak dekho",
        f"Ye 3D cartoon dekh ke hans padoge 😂",
        f"{title} | 3D Cartoon Shorts",
        f"Part 2 chahiye? Comment karo 👇",
    ]
    tags = uniq(NICHE_TAGS.get(niche, NICHE_TAGS["default"]) + CORE)
    hashtags = meta.get("hashtags") or ["#" + t for t in tags][:14]
    hashtags = [h if h.startswith("#") else "#" + h for h in hashtags]

    desc = meta.get("description") or (
        f"{hook}\n\n"
        f"{title} - mazedaar 3D cartoon animation short. Poora dekho, end mein twist hai! 👀\n\n"
        f"👍 Like | 💬 Comment | 🔁 Share | ➕ {cta}\n\n"
        + " ".join(hashtags[:10])
    )
    keywords = meta.get("keywords") or tags
    pinned = meta.get("pinned_comment") or "Aapko sabse achha kaunsa scene laga? Comment mein batao 👇 Part 2 ke liye 100 likes!"
    thumb = meta.get("thumbnail_text") or (hook[:28].upper())
    hints = meta.get("onscreen_hints") or ["End tak dekho 👀", "Wait for it...", "Last mein twist hai!"]
    post_time = meta.get("best_time_ist") or "Roz 12:30 PM ya 7:00-9:00 PM IST (Reels/Shorts peak)"

    L = []
    L.append("=== TITLE OPTIONS (pehla use karo, baaki A/B test) ===")
    L += [f"{i+1}. {t}" for i, t in enumerate(titles)]
    L.append("\n=== DESCRIPTION / CAPTION (copy-paste) ===")
    L.append(desc)
    L.append("\n=== HASHTAGS ===")
    L.append(" ".join(hashtags))
    L.append("\n=== KEYWORDS / TAGS (YouTube Studio tags box, comma separated) ===")
    L.append(", ".join(keywords))
    L.append("\n=== PINNED COMMENT ===")
    L.append(pinned)
    L.append("\n=== THUMBNAIL TEXT ===")
    L.append(thumb)
    L.append("\n=== ON-SCREEN HINTS (retention) ===")
    L += ["- " + h for h in hints]
    L.append("\n=== BEST TIME TO POST ===")
    L.append(post_time)
    L.append("\n=== POSTING CHECKLIST ===")
    L += [
        "1. Pehle 1 ghante mein har comment ka reply do (reach badhta hai)",
        "2. Same video Reels + Shorts + Facebook par daalo (alag alag din / ghante)",
        "3. Pinned comment turant lagao",
        "4. 3 din tak watch-time dekho; jis hook par drop ho, agli video mein badlo",
    ]
    open(sys.argv[2], "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("wrote", sys.argv[2])


if __name__ == "__main__":
    main()
