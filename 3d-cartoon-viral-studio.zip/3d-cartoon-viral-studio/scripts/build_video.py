#!/usr/bin/env python3
"""
build_video.py - storyboard.json  ->  finished viral 3D cartoon short (1080x1920 MP4)

One command does everything:
  3D render -> auto-edit (punch zooms, flashes, shake, progress bar)
  -> hook/hint/word-by-word captions (ASS) -> synth music+SFX (or your voice, ducked)
  -> loudness -14 LUFS -> thumbnail -> captions.srt -> metadata.txt -> QC + auto-fix

usage:
  python3 build_video.py storyboard.json --out outdir [--voice voice.mp3]
         [--quality draft|hd|fast] [--fps 30] [--max-seconds N]
"""
import argparse
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import render3d as R  # noqa: E402

CAM_DEFAULT = dict(orbit=[0, 0], dist=[9.5, 8.6], height=[2.4, 2.2], target=[0, 1.15, 0], fov=40)


def sh(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        sys.stderr.write(r.stderr[-1500:])
        raise SystemExit(f"command failed: {' '.join(cmd[:4])} ...")
    return r.stdout + r.stderr


def probe_dur(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "csv=p=0", path], capture_output=True, text=True).stdout
    return float(out.strip())


def pair(v, default):
    v = default if v is None else v
    return (v[0], v[1]) if isinstance(v, (list, tuple)) else (v, v)


def cam_at(c, u, shake=0.0, t=0.0):
    c = {**CAM_DEFAULT, **(c or {})}
    e = R.ease(u)
    o0, o1 = pair(c["orbit"], [0, 0])
    d0, d1 = pair(c["dist"], [9.5, 8.6])
    h0, h1 = pair(c["height"], [2.4, 2.2])
    a = math.radians(R.lerp(o0, o1, e))
    d = R.lerp(d0, d1, e)
    h = R.lerp(h0, h1, e)
    tx, ty, tz = c["target"]
    eye = (tx + d * math.sin(a), h, tz + d * math.cos(a))
    if shake:
        eye = (eye[0] + shake * math.sin(t * 90), eye[1] + shake * math.cos(t * 77), eye[2])
    return dict(eye=eye, target=(tx, ty, tz), fov=c.get("fov", 40))


# ------------------------------------------------------------ storyboard
def load_storyboard(path, args):
    sb = json.load(open(path, encoding="utf-8"))
    sb.setdefault("fps", 30)
    sb.setdefault("bpm", 110)
    sb.setdefault("theme", "day")
    sb.setdefault("hook", sb.get("title", ""))
    sb.setdefault("mood", "fun")
    sb.setdefault("characters", {"hero": dict(style="blob", color="#ff8a3d")})
    if args.fps:
        sb["fps"] = args.fps
    scenes = sb["scenes"]
    if sb.get("end_card") and not any(s.get("is_end") for s in scenes):
        hero = next(iter(sb["characters"]))
        scenes.append(dict(dur=2.4, is_end=True, caption="", env=sb["theme"],
                           actors=[dict(id=hero, action="wave", x=0)],
                           cam=dict(dist=[8.5, 7.2], height=[2.0, 1.8]), punch=True))
    return sb


def apply_voice(sb, voice, outdir):
    if not voice:
        return None
    clean = os.path.join(outdir, "voice_clean.wav")
    sh(["ffmpeg", "-y", "-i", voice, "-af",
        "silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=-1:"
        "stop_duration=0.35:stop_threshold=-45dB,highpass=f=80,acompressor=threshold=-18dB:ratio=3",
        "-ar", "44100", "-ac", "2", clean])
    vd = probe_dur(clean)
    total = sum(s["dur"] for s in sb["scenes"])
    target = min(58.0, vd + 0.9)
    k = target / total
    for s in sb["scenes"]:
        s["dur"] = round(s["dur"] * k, 3)
    print(f"voice {vd:.1f}s -> scenes scaled x{k:.2f}")
    return clean


# -------------------------------------------------------------- captions
def ass_time(t):
    t = max(0.0, t)
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


_EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿️‍⭐⬆↔-↪]+")


def strip_emoji(s):
    """libass cannot draw colour emoji -> remove from burned-in text (keep in metadata)."""
    return re.sub(r"\s{2,}", " ", _EMOJI.sub("", s)).strip()


def esc(s):
    return strip_emoji(s).replace("{", "(").replace("}", ")").replace("\n", "\\N")


def chunk_words(words, maxw=3, maxc=20):
    chunks, cur = [], []
    for w in words:
        if cur and (len(cur) >= maxw or len(" ".join(cur + [w])) > maxc):
            chunks.append(cur)
            cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    return chunks


def build_ass(sb, starts, ends, path, font):
    W, H = 1080, 1920
    hdr = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{font},92,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,9,3,2,70,70,430,1
Style: Hook,{font},104,&H0000E5FF,&H0000E5FF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,10,4,8,70,70,250,1
Style: Hint,{font},58,&H00FFFFFF,&H00FFFFFF,&H90000000,&H00000000,-1,0,0,0,100,100,0,0,3,16,0,8,70,70,120,1
Style: End,{font},100,&H0000E5FF,&H0000E5FF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,10,4,5,70,70,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev = []
    hook_end = min(2.8, ends[0] - starts[0])
    if sb.get("hook"):
        ev.append(f"Dialogue: 2,{ass_time(0.05)},{ass_time(hook_end)},Hook,,0,0,0,,"
                  f"{{\\fad(100,220)\\fscx55\\fscy55\\t(0,170,\\fscx100\\fscy100)}}{esc(sb['hook'])}")
    srt, n = [], 1
    for i, s in enumerate(sb["scenes"]):
        st, en = starts[i], ends[i]
        cap = (s.get("caption") or "").strip()
        if cap:
            words = cap.split()
            t0, t1 = st + 0.12, en - 0.08
            wts = [len(w) + 2 for w in words]
            tot = sum(wts)
            times, acc = [], t0
            for wt in wts:
                times.append(acc)
                acc += (t1 - t0) * wt / tot
            times.append(t1)
            idx = 0
            for ch in chunk_words(words):
                for j in range(len(ch)):
                    a, b = times[idx + j], times[idx + j + 1]
                    parts = []
                    for k, w in enumerate(ch):
                        if k == j:
                            parts.append("{\\c&H00E5FF&\\fscx118\\fscy118\\t(0,90,\\fscx100\\fscy100)}"
                                         + esc(w) + "{\\c&HFFFFFF&}")
                        else:
                            parts.append(esc(w))
                    ev.append(f"Dialogue: 1,{ass_time(a)},{ass_time(b)},Cap,,0,0,0,,{' '.join(parts)}")
                idx += len(ch)
            srt.append((n, st + 0.12, en - 0.08, cap))
            n += 1
        if s.get("hint") and not s.get("is_end"):
            ev.append(f"Dialogue: 3,{ass_time(st + 0.5)},{ass_time(en - 0.15)},Hint,,0,0,0,,"
                      f"{{\\fad(150,150)}}{esc(s['hint'])}")
        if s.get("is_end") and sb.get("end_card"):
            ev.append(f"Dialogue: 3,{ass_time(st + 0.1)},{ass_time(en)},End,,0,0,0,,"
                      f"{{\\fad(200,0)\\fscx60\\fscy60\\t(0,200,\\fscx100\\fscy100)}}{esc(sb['end_card'])}")
    open(path, "w", encoding="utf-8").write(hdr + "\n".join(ev) + "\n")
    return srt


def write_srt(srt, path):
    def ts(t):
        ms = int(round(t * 1000))
        return f"{ms // 3600000:02d}:{ms % 3600000 // 60000:02d}:{ms % 60000 // 1000:02d},{ms % 1000:03d}"
    with open(path, "w", encoding="utf-8") as f:
        for n, a, b, text in srt:
            f.write(f"{n}\n{ts(a)} --> {ts(b)}\n{text}\n\n")


# ------------------------------------------------------------- rendering
def scene_ells(sb, scene, lt, dur):
    ells = []
    for ac in scene.get("actors", []):
        ch = sb["characters"].get(ac["id"], dict(style="blob", color="#ff8a3d"))
        x0 = ac.get("x", 0.0)
        x1 = ac.get("x1", x0)
        pose, dx, dz, yaw = R.action_pose(ac.get("action", "idle"), lt + ac.get("t_off", 0.0), dur, x0, x1)
        ells += R.make_character(ch.get("style", "blob"), ch.get("color", "#ff8a3d"),
                                 x=x0 + dx, z=ac.get("z", 0.0) + dz,
                                 yaw=ac.get("face", 0.0) + yaw, pose=pose, scale=ch.get("scale", 1.0))
    for pr in scene.get("props", []):
        ells += R.make_prop(pr, lt)
    return ells


def compose(img, W, H, lf, nf, fps, scene_idx, scene, prog, vig):
    lt = lf / fps
    out = img
    if scene.get("punch", True):
        k = min(1.0, lf / 8.0)
        s = 1.0 + (0.16 if scene_idx > 0 else 0.07) * (1 - R.ease(k))
        if s > 1.001:
            M = cv2.getRotationMatrix2D((W / 2, H / 2), 0, s)
            out = cv2.warpAffine(out, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    if scene.get("shake"):
        amp = 14 * math.exp(-lt * 5.0) * W / 540
        if amp > 0.4:
            M = np.float32([[1, 0, random.uniform(-amp, amp)], [0, 1, random.uniform(-amp, amp)]])
            out = cv2.warpAffine(out, M, (W, H), borderMode=cv2.BORDER_REFLECT)
    if scene_idx > 0 and lf < 3:
        a = 0.55 * (1 - lf / 3.0)
        out = cv2.addWeighted(out, 1 - a, np.full_like(out, 255), a, 0)
    out = (out.astype(np.float32) * vig).astype(np.uint8)
    cv2.rectangle(out, (0, 0), (int(W * prog), max(4, H // 85)), (0, 220, 255), -1)
    if scene.get("is_end"):
        fade = min(1.0, lt / 0.5) * 0.45
        out = (out.astype(np.float32) * (1 - fade)).astype(np.uint8)
    return out


def find_font():
    try:
        name = subprocess.run(["fc-match", "-f", "%{family}", "Inter:bold"],
                              capture_output=True, text=True).stdout.split(",")[0].strip()
        if name:
            return name
    except Exception:
        pass
    return "DejaVu Sans"


def make_thumbnail(frame_bgr, text, path):
    W, H = 1080, 1920
    big = cv2.resize(frame_bgr, (W, H), interpolation=cv2.INTER_CUBIC)
    try:
        from PIL import Image, ImageDraw, ImageFont
        fp = subprocess.run(["fc-match", "-f", "%{file}", "Inter:bold"], capture_output=True, text=True).stdout
        if not fp or not os.path.exists(fp):
            fp = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        im = Image.fromarray(big[..., ::-1])
        d = ImageDraw.Draw(im)
        words = text.upper().split()
        lines, cur = [], ""
        for w in words:
            if len(cur + " " + w) > 12 and cur:
                lines.append(cur)
                cur = w
            else:
                cur = (cur + " " + w).strip()
        lines.append(cur)
        size = 190 if max(len(l) for l in lines) <= 8 else 150
        f = ImageFont.truetype(fp, size)
        y = 190
        for l in lines[:3]:
            wbox = d.textlength(l, font=f)
            x = (W - wbox) / 2
            d.text((x, y), l, font=f, fill=(255, 229, 0), stroke_width=14, stroke_fill=(0, 0, 0))
            y += size + 20
        im.convert("RGB").save(path, quality=92)
    except Exception as e:  # fallback without PIL fonts
        cv2.putText(big, text[:18], (60, 300), cv2.FONT_HERSHEY_DUPLEX, 3, (0, 229, 255), 8)
        cv2.imwrite(path, big)


def render_video(sb, W, H, fps, max_sec, silent_path):
    scenes = sb["scenes"]
    starts, ends, t = [], [], 0.0
    for s in scenes:
        starts.append(t)
        t += s["dur"]
        ends.append(t)
    total = min(t, max_sec) if max_sec else t
    nframes = int(round(total * fps))
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dist = np.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
    vig = (1 - 0.22 * np.clip(dist - 0.55, 0, 1) ** 1.5)[..., None].astype(np.float32)

    ff = subprocess.Popen(
        ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}",
         "-r", str(fps), "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "15",
         "-pix_fmt", "yuv420p", silent_path], stdin=subprocess.PIPE)
    thumb_frame, thumb_t = None, None
    for i, s in enumerate(scenes):
        if s.get("thumb"):
            thumb_t = starts[i] + min(1.0, s["dur"] * 0.4)
    if thumb_t is None:
        thumb_t = starts[min(1, len(scenes) - 1)] + 1.0
    random.seed(7)
    si = 0
    for f in range(nframes):
        T = f / fps
        while si < len(scenes) - 1 and T >= ends[si]:
            si += 1
        s = scenes[si]
        lt = T - starts[si]
        lf = int(round(lt * fps))
        u = lt / max(s["dur"], 0.01)
        shake = 0.05 * math.exp(-lt * 4) if s.get("shake") else 0.0
        cam = cam_at(s.get("cam"), u, shake, lt)
        ells = scene_ells(sb, s, lt, s["dur"])
        img = R.render(ells, cam, W, H, s.get("env", sb["theme"]))
        img = compose(img, W, H, lf, int(s["dur"] * fps), fps, si, s, T / total, vig)
        if thumb_frame is None and T >= thumb_t:
            thumb_frame = img.copy()
        ff.stdin.write(img.tobytes())
        if f % (fps * 2) == 0:
            print(f"  render {f}/{nframes}", flush=True)
    ff.stdin.close()
    ff.wait()
    return starts, ends, total, thumb_frame if thumb_frame is not None else img


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("storyboard")
    ap.add_argument("--out", default="out")
    ap.add_argument("--voice")
    ap.add_argument("--quality", default="draft", choices=["draft", "hd", "fast"])
    ap.add_argument("--fps", type=int)
    ap.add_argument("--max-seconds", type=float)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    out = os.path.abspath(args.out)
    sb = load_storyboard(args.storyboard, args)
    if args.quality == "fast" and not args.fps:
        sb["fps"] = 24
    W, H = {"draft": (540, 960), "hd": (720, 1280), "fast": (432, 768)}[args.quality]
    fps = sb["fps"]

    voice_clean = apply_voice(sb, args.voice, out)
    silent = os.path.join(out, "silent.mp4")
    print(f"[1/5] rendering 3D frames {W}x{H} @ {fps}fps ...")
    starts, ends, total, thumb = render_video(sb, W, H, fps, args.max_seconds, silent)

    print("[2/5] captions + thumbnail ...")
    font = find_font()
    srt = build_ass(sb, starts, ends, os.path.join(out, "captions.ass"), font)
    write_srt(srt, os.path.join(out, "captions.srt"))
    make_thumbnail(thumb, strip_emoji(sb.get("thumbnail_text") or sb.get("hook") or sb.get("title", "")),
                   os.path.join(out, "thumbnail.jpg"))

    print("[3/5] audio ...")
    music = os.path.join(out, "music_sfx.wav")
    sh([sys.executable, os.path.join(HERE, "make_audio.py"), music, "--dur", f"{total:.2f}",
        "--bpm", str(sb["bpm"]), "--cuts", ",".join(f"{x:.2f}" for x in starts), "--mood", sb["mood"]])

    print("[4/5] final mix + export ...")
    final = os.path.join(out, "final.mp4")
    vf = "[0:v]scale=1080:1920:flags=lanczos,ass=captions.ass[v]"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", "silent.mp4", "-i", "music_sfx.wav"]
    if voice_clean:
        cmd += ["-i", "voice_clean.wav"]
        af = ("[2:a]asplit=2[vk][vm];[1:a]volume=0.55[m0];"
              "[m0][vk]sidechaincompress=threshold=0.04:ratio=10:attack=15:release=250[md];"
              "[vm]volume=1.3[vv];[md][vv]amix=inputs=2:duration=first:normalize=0[mix];"
              "[mix]loudnorm=I=-14:TP=-1.5:LRA=11[a]")
    else:
        af = "[1:a]volume=0.9,loudnorm=I=-14:TP=-1.5:LRA=11[a]"
    cmd += ["-filter_complex", vf + ";" + af, "-map", "[v]", "-map", "[a]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "19", "-pix_fmt", "yuv420p",
            "-r", str(fps), "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-movflags", "+faststart",
            "-t", f"{total:.2f}", "final.mp4"]
    sh(cmd, cwd=out)

    print("[5/5] metadata + QC ...")
    json.dump(sb, open(os.path.join(out, "storyboard_used.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    sh([sys.executable, os.path.join(HERE, "metadata.py"), os.path.join(out, "storyboard_used.json"),
        os.path.join(out, "metadata.txt")])
    qc = [sys.executable, os.path.join(HERE, "qc_check.py"), final]
    r = subprocess.run(qc, capture_output=True, text=True)
    print(r.stdout)
    if r.returncode != 0:
        autofix(final, r.stdout, out)
        r = subprocess.run(qc, capture_output=True, text=True)
        print("after auto-fix:\n" + r.stdout)

    for f in ("silent.mp4", "voice_clean.wav"):
        p = os.path.join(out, f)
        if os.path.exists(p):
            os.remove(p)
    print("DONE ->", out)


def autofix(final, report, out):
    tmp = os.path.join(out, "fixed.mp4")
    if "FAIL loudness" in report:
        # two-pass loudnorm: measure first, then apply exact correction
        m1 = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", final, "-af",
                             "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                            capture_output=True, text=True).stderr
        mm = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", m1, re.S)
        if mm:
            d = json.loads(mm.group(0))
            af = ("loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=%s:measured_LRA=%s:measured_TP=%s:"
                  "measured_thresh=%s:offset=%s:linear=true" %
                  (d["input_i"], d["input_lra"], d["input_tp"], d["input_thresh"], d["target_offset"]))
        else:
            af = "loudnorm=I=-14:TP=-1.5:LRA=11"
        sh(["ffmpeg", "-y", "-loglevel", "error", "-i", final, "-c:v", "copy", "-af", af,
            "-ar", "44100", "-c:a", "aac", "-b:a", "192k", tmp])
        shutil.move(tmp, final)
    if "FAIL size < 100MB" in report:
        sh(["ffmpeg", "-y", "-loglevel", "error", "-i", final, "-c:v", "libx264", "-crf", "24",
            "-preset", "veryfast", "-c:a", "copy", tmp])
        shutil.move(tmp, final)


if __name__ == "__main__":
    main()
