#!/usr/bin/env python3
"""
make_audio.py - generates a royalty-free bouncy background loop + pop/whoosh SFX
(100% synthesized with numpy, so there is no copyright risk).

usage: make_audio.py OUT.wav --dur 24.5 --bpm 110 --cuts 0,3.0,6.5 [--mood fun|calm|spooky|hype]
"""
import argparse
import wave
import numpy as np

SR = 44100


def env_adsr(n, a=0.005, d=0.08, s=0.3, r=0.1):
    e = np.ones(n, np.float32)
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na, nd, nr = min(na, n), min(nd, max(0, n - na)), min(nr, n)
    if na:
        e[:na] = np.linspace(0, 1, na)
    if nd:
        e[na:na + nd] = np.linspace(1, s, nd)
    e[na + nd:] = s
    if nr:
        e[-nr:] *= np.linspace(1, 0, nr)
    return e


def tone(freq, dur, kind="tri", vol=0.3):
    n = int(dur * SR)
    t = np.arange(n) / SR
    ph = 2 * np.pi * freq * t
    if kind == "sine":
        w = np.sin(ph)
    elif kind == "sq":
        w = np.sign(np.sin(ph)) * 0.6
    else:
        w = 2 / np.pi * np.arcsin(np.sin(ph))
    return (w * env_adsr(n) * vol).astype(np.float32)


def kick(vol=0.9):
    n = int(0.22 * SR)
    t = np.arange(n) / SR
    f = 120 * np.exp(-t * 28) + 45
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) * np.exp(-t * 14) * vol).astype(np.float32)


def hat(vol=0.18):
    n = int(0.05 * SR)
    r = np.random.RandomState(3).randn(n).astype(np.float32)
    r = np.diff(r, prepend=0)
    return (r * np.exp(-np.arange(n) / SR * 90) * vol).astype(np.float32)


def clap(vol=0.35):
    n = int(0.12 * SR)
    r = np.random.RandomState(5).randn(n).astype(np.float32)
    return (r * np.exp(-np.arange(n) / SR * 35) * vol).astype(np.float32)


def pop(vol=0.7):
    n = int(0.16 * SR)
    t = np.arange(n) / SR
    f = 900 * np.exp(-t * 18) + 150
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) * np.exp(-t * 22) * vol).astype(np.float32)


def whoosh(dur=0.35, vol=0.35):
    n = int(dur * SR)
    t = np.arange(n) / SR
    r = np.random.RandomState(7).randn(n).astype(np.float32)
    k = 40
    sm = np.convolve(r, np.ones(k) / k, mode="same")
    env = np.sin(np.pi * t / dur) ** 2
    return (sm * env * vol * 6).astype(np.float32)


def mix_at(buf, snd, at):
    i = int(at * SR)
    if i >= len(buf):
        return
    j = min(len(buf), i + len(snd))
    buf[i:j] += snd[:j - i]


MOODS = {
    "fun":    dict(scale=[0, 2, 4, 7, 9], root=261.63, pat="x.x.x.x."),
    "hype":   dict(scale=[0, 3, 5, 7, 10], root=220.0, pat="xxx.xxx."),
    "calm":   dict(scale=[0, 2, 4, 7, 9], root=196.0, pat="x...x..."),
    "spooky": dict(scale=[0, 1, 3, 6, 7], root=174.61, pat="x..x..x."),
}


def build(dur, bpm, cuts, mood="fun"):
    m = MOODS.get(mood, MOODS["fun"])
    n = int((dur + 0.5) * SR)
    L = np.zeros(n, np.float32)
    beat = 60.0 / bpm
    rng = np.random.RandomState(11)
    steps = int((dur + 0.5) / (beat / 2)) + 1
    prog = [0, 3, 4, 3]  # scale-degree walk for bass
    for s in range(steps):
        t = s * beat / 2
        bar = (s // 8) % 4
        # drums
        if s % 2 == 0:
            mix_at(L, kick(), t)
        if s % 4 == 2:
            mix_at(L, clap(), t)
        mix_at(L, hat(0.12 if s % 2 else 0.2), t)
        # bass
        if m["pat"][s % 8] == "x":
            deg = m["scale"][prog[bar] % len(m["scale"])]
            f = m["root"] / 2 * 2 ** (deg / 12)
            mix_at(L, tone(f, beat * 0.45, "sq", 0.16), t)
        # pluck melody
        if rng.rand() < 0.62:
            deg = m["scale"][rng.randint(0, len(m["scale"]))]
            f = m["root"] * 2 * 2 ** (deg / 12)
            mix_at(L, tone(f, beat * 0.3, "tri", 0.2), t)
    for c in cuts:
        mix_at(L, pop(), c)
        if c > 0.2:
            mix_at(L, whoosh(), max(0.0, c - 0.18))
    L = L[: int(dur * SR)]
    fade = int(0.6 * SR)
    L[-fade:] *= np.linspace(1, 0, fade)
    pk = np.max(np.abs(L)) + 1e-6
    return (L / pk * 0.9).astype(np.float32)


def write_wav(path, mono):
    st = np.stack([mono, mono], 1)
    data = (np.clip(st, -1, 1) * 32767).astype("<i2").tobytes()
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--dur", type=float, required=True)
    ap.add_argument("--bpm", type=float, default=110)
    ap.add_argument("--cuts", default="0")
    ap.add_argument("--mood", default="fun")
    a = ap.parse_args()
    cuts = [float(x) for x in a.cuts.split(",") if x.strip()]
    write_wav(a.out, build(a.dur, a.bpm, cuts, a.mood))
    print("wrote", a.out)
