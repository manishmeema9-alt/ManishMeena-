#!/usr/bin/env python3
"""
render3d.py - tiny toon-style 3D renderer (numpy ray-casting, no GPU, no Blender).

Real 3D: perspective camera, ellipsoid characters, checker ground, toon shading,
rim light, soft ground shadows, ink outlines. Used by build_video.py.
Public API:
    Scene building : make_character(), make_prop()
    Animation      : action_pose()
    Rendering      : render(ells, cam, W, H, env)
"""
import math
import numpy as np
import cv2

# ----------------------------------------------------------------- helpers
def hex2rgb(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], np.float32) / 255.0


def ease(t):
    t = min(1.0, max(0.0, t))
    return t * t * (3 - 2 * t)


def lerp(a, b, t):
    return a + (b - a) * t


class Ell:
    """Axis-aligned ellipsoid."""
    __slots__ = ("c", "r", "col", "shadow", "glow")

    def __init__(self, c, r, col, shadow=False, glow=0.0):
        self.c = np.array(c, np.float32)
        self.r = np.array(r, np.float32)
        self.col = np.array(col, np.float32)
        self.shadow = shadow
        self.glow = glow


ENVS = {
    "day":    dict(top="#5ec8ff", bot="#d8f4ff", ga="#8be36a", gb="#79d159"),
    "sunset": dict(top="#ff7a9c", bot="#ffd27a", ga="#9b6bd6", gb="#8a5bc4"),
    "night":  dict(top="#0b0f3a", bot="#3a2a7a", ga="#2a3a6a", gb="#243260"),
    "candy":  dict(top="#ff9de6", bot="#fff1a8", ga="#ffb3d9", gb="#ffd1ec"),
    "space":  dict(top="#05020f", bot="#2b1060", ga="#3a2a55", gb="#30224a"),
    "snow":   dict(top="#a9d8ff", bot="#f4fbff", ga="#ffffff", gb="#e4f1fb"),
    "desert": dict(top="#ffb36b", bot="#ffe9b8", ga="#f2c27a", gb="#e8b46a"),
}


# ------------------------------------------------------------- characters
def _rot(v, yaw):
    c, s = math.cos(yaw), math.sin(yaw)
    return np.array([v[0] * c + v[2] * s, v[1], -v[0] * s + v[2] * c], np.float32)


def make_character(style, color, x=0.0, z=0.0, yaw=0.0, pose=None, scale=1.0):
    """Return list[Ell] for one character. style: blob | bunny | cat | robot."""
    p = dict(bounce=0.0, squash=0.0, walk=None, arm_l=0.15, arm_r=0.15,
             look=(0.0, 0.0), blink=0.0, mouth=0.1, eyes=1.0, lean=0.0)
    if pose:
        p.update(pose)
    body = hex2rgb(color)
    belly = np.clip(body * 0.35 + 0.65, 0, 1)
    dark = body * 0.68
    if style == "robot":
        belly = np.array([0.85, 0.95, 1.0], np.float32)
    white = np.array([1, 1, 1], np.float32)
    ink = np.array([0.1, 0.06, 0.14], np.float32)
    pink = np.array([1.0, 0.55, 0.65], np.float32)

    sy = 1.0 + p["squash"]
    sxz = 1.0 / math.sqrt(max(0.5, sy))
    base = np.array([x, 0.0, z], np.float32)
    out = []

    def add(local, radii, col, shadow=False, glow=0.0):
        l = np.array(local, np.float32)
        l = np.array([l[0] * sxz, l[1] * sy, l[2] * sxz], np.float32)
        l[0] += p["lean"] * max(0.0, l[1]) * 0.25
        l = _rot(l * scale, yaw)
        r = np.array([radii[0] * sxz, radii[1] * sy, radii[2] * sxz], np.float32) * scale
        c = base + l + np.array([0, p["bounce"], 0], np.float32)
        out.append(Ell(c, r, col, shadow, glow))

    # feet
    w = p["walk"]
    for side in (-1, 1):
        fz, fy = 0.12, 0.13
        if w is not None:
            ph = w + (math.pi if side > 0 else 0.0)
            fz += math.sin(ph) * 0.32
            fy += max(0.0, math.cos(ph)) * 0.16
        add((side * 0.27, fy, fz), (0.24, 0.14, 0.32), dark, shadow=True)
    # body + belly
    add((0, 0.72, 0), (0.58, 0.62, 0.52), body, shadow=True)
    add((0, 0.62, 0.40), (0.36, 0.40, 0.2), belly)
    # head
    hc = np.array([0, 1.62, 0], np.float32)
    hr = np.array([0.66, 0.58, 0.60], np.float32)
    if style == "robot":
        hr = np.array([0.62, 0.52, 0.56], np.float32)
    add(hc, hr, body, shadow=True)
    # ears / extras
    if style == "bunny":
        for side in (-1, 1):
            add(hc + np.array([side * 0.28, 0.85, 0.0]), (0.14, 0.5, 0.1), body)
            add(hc + np.array([side * 0.28, 0.85, 0.07]), (0.07, 0.38, 0.05), pink)
    elif style == "cat":
        for side in (-1, 1):
            add(hc + np.array([side * 0.44, 0.52, 0.0]), (0.2, 0.26, 0.1), body)
            add(hc + np.array([side * 0.44, 0.50, 0.07]), (0.1, 0.15, 0.04), pink)
    elif style == "robot":
        add(hc + np.array([0, 0.62, 0]), (0.03, 0.28, 0.03), ink)
        add(hc + np.array([0, 0.95, 0]), (0.11, 0.11, 0.11), np.array([1, .25, .3], np.float32), glow=0.6)
    # face
    for side in (-1, 1):
        d = np.array([side * 0.36, 0.12, 0.92], np.float32)
        d /= np.linalg.norm(d)
        epos = hc + hr * d * 0.93
        es = p["eyes"]
        bl = 1.0 - 0.9 * p["blink"]
        add(epos, (0.19 * es, 0.23 * es * bl, 0.12), white)
        if p["blink"] < 0.8:
            lk = p["look"]
            ppos = epos + np.array([lk[0] * 0.07, lk[1] * 0.07, 0.10])
            add(ppos, (0.1 * es, 0.12 * es, 0.06), ink)
            add(ppos + np.array([0.03, 0.04, 0.05]), (0.035, 0.035, 0.03), white)
    if style in ("blob", "bunny", "cat", "robot"):
        d = np.array([0, -0.38, 0.92], np.float32)
        d /= np.linalg.norm(d)
        mo = float(p["mouth"])
        add(hc + hr * d * 0.97, (0.15, 0.03 + 0.13 * mo, 0.05), np.array([0.4, 0.04, 0.1], np.float32))
    if style in ("bunny", "cat"):
        add(hc + hr * np.array([0, -0.08, 0.99]), (0.07, 0.05, 0.05), pink)
    for side in (-1, 1):
        d = np.array([side * 0.72, -0.2, 0.66], np.float32)
        d /= np.linalg.norm(d)
        add(hc + hr * d * 0.92, (0.11, 0.07, 0.04), pink)
    # arms (3 round segments along the arm direction)
    for side, ang in ((-1, p["arm_l"]), (1, p["arm_r"])):
        sh = np.array([side * 0.52, 0.85, 0.05], np.float32)
        dirv = np.array([side * math.sin(ang), -math.cos(ang), 0.0], np.float32)
        for k, (dist, rad) in enumerate(((0.18, 0.15), (0.40, 0.15), (0.62, 0.19))):
            add(sh + dirv * dist, (rad, rad, rad), white if k == 2 else body)
    return out


# ------------------------------------------------------------------ props
def make_prop(spec, t):
    kind = spec.get("type", "ball")
    px, py, pz = spec.get("pos", [0, 0, 0])
    col = hex2rgb(spec.get("color", "#ffd23f"))
    s = float(spec.get("size", 1.0))
    out = []
    if kind == "ball":
        r = 0.4 * s
        y = r + (abs(math.sin(t * 4)) * 0.9 if spec.get("bounce") else 0.0)
        out.append(Ell((px, y + py, pz), (r, r, r), col, shadow=True))
    elif kind == "tree":
        out.append(Ell((px, 0.7 * s, pz), (0.16 * s, 0.7 * s, 0.16 * s), hex2rgb("#8a5a2b"), shadow=True))
        g = hex2rgb(spec.get("color", "#3fbf5a"))
        out.append(Ell((px, 1.7 * s, pz), (0.8 * s, 0.7 * s, 0.8 * s), g, shadow=True))
        out.append(Ell((px, 2.3 * s, pz), (0.55 * s, 0.5 * s, 0.55 * s), g * 1.08 + 0.02))
    elif kind == "cloud":
        dx = math.sin(t * 0.5) * 0.4
        for ox, oy, rr in ((0, 0, 0.7), (0.7, -0.1, 0.55), (-0.7, -0.1, 0.55), (0.2, 0.35, 0.5)):
            out.append(Ell((px + dx + ox * s, py + oy * s, pz), (rr * s, rr * 0.7 * s, rr * 0.7 * s),
                           np.array([1, 1, 1], np.float32)))
    elif kind == "gem":
        y = py + 0.25 * math.sin(t * 3)
        out.append(Ell((px, y, pz), (0.28 * s, 0.42 * s, 0.28 * s), col, glow=0.5))
    elif kind == "hill":
        out.append(Ell((px, py - 0.4 * s, pz), (3.2 * s, 1.6 * s, 2.2 * s), col, shadow=False))
    elif kind == "box":
        for i in range(3):
            out.append(Ell((px, 0.35 * s + i * 0.55 * s, pz), (0.5 * s, 0.3 * s, 0.5 * s), col, shadow=(i == 0)))
    return out


# ----------------------------------------------------------- animation lib
def action_pose(action, t, dur=3.0, x0=0.0, x1=0.0):
    """Return (pose dict, dx, dz, yaw_offset). t seconds from scene start."""
    P = {}
    dx = dz = 0.0
    yaw = 0.0
    u = ease(t / max(dur, 0.01))
    blink = 1.0 if (t % 3.1) < 0.12 else 0.0
    P["blink"] = blink
    sw = math.sin(t * 2.0)
    P["bounce"] = 0.03 * abs(math.sin(t * 2.4))
    P["squash"] = 0.03 * math.sin(t * 4.8)
    P["arm_l"] = 0.2 + 0.05 * sw
    P["arm_r"] = 0.2 - 0.05 * sw

    if action == "bounce" or action == "jump":
        per = 0.8
        ph = (t / per) % 1.0
        h = 1.3
        if ph < 0.15:
            k = ease(ph / 0.15)
            P["squash"] = -0.30 * k
            P["bounce"] = 0
            P["arm_l"] = P["arm_r"] = 0.1
        elif ph < 0.85:
            k = (ph - 0.15) / 0.7
            P["bounce"] = h * 4 * k * (1 - k)
            P["squash"] = 0.2 * math.sin(k * math.pi)
            P["arm_l"] = P["arm_r"] = 2.6 * math.sin(k * math.pi) + 0.2
            P["mouth"] = 0.9
        else:
            k = ease((ph - 0.85) / 0.15)
            P["squash"] = -0.30 * (1 - k)
            P["bounce"] = 0
    elif action == "walk":
        P["walk"] = t * 9.0
        P["bounce"] = 0.07 * abs(math.sin(t * 9.0))
        P["arm_l"] = 0.5 + 0.5 * math.sin(t * 9.0)
        P["arm_r"] = 0.5 - 0.5 * math.sin(t * 9.0)
        P["mouth"] = 0.25
        dx = lerp(x0, x1, u) - x0
        yaw = 0.8 if x1 >= x0 else -0.8
        P["lean"] = 0.15
    elif action == "wave":
        P["arm_r"] = 2.7 + 0.35 * math.sin(t * 11)
        P["mouth"] = 0.55
        P["bounce"] = 0.05 * abs(math.sin(t * 3))
    elif action == "dance":
        b = abs(math.sin(t * 6.0))
        P["bounce"] = 0.28 * b
        P["squash"] = 0.18 * math.cos(t * 12.0)
        P["arm_l"] = 1.5 + 1.5 * (0.5 + 0.5 * math.sin(t * 6.0))
        P["arm_r"] = 1.5 + 1.5 * (0.5 + 0.5 * math.cos(t * 6.0))
        P["mouth"] = 0.8
        yaw = 0.55 * math.sin(t * 3.0)
        dx = 0.3 * math.sin(t * 3.0)
        P["walk"] = t * 12.0
    elif action == "scared":
        if t < 0.25:
            k = t / 0.25
            P["squash"] = -0.25 * k
        else:
            k = min(1.0, (t - 0.25) / 0.45)
            P["bounce"] = 0.9 * 4 * k * (1 - k) if k < 1 else 0.0
            P["squash"] = 0.2 * math.sin(k * math.pi)
        dx = 0.06 * math.sin(t * 60.0)
        P["arm_l"] = P["arm_r"] = 2.8
        P["eyes"] = 1.45
        P["mouth"] = 1.0
        P["look"] = (0.6, 0.2)
        dz = -0.6 * ease(t / 0.8)
    elif action == "spin":
        yaw = 2 * math.pi * (t / 1.1)
        P["bounce"] = 0.35 * abs(math.sin(t * 2.8))
        P["arm_l"] = P["arm_r"] = 1.6
        P["mouth"] = 0.8
    elif action == "celebrate":
        per = 0.7
        ph = (t / per) % 1.0
        P["bounce"] = 1.1 * 4 * ph * (1 - ph)
        P["squash"] = 0.2 * math.sin(ph * math.pi) - (0.2 if ph < 0.1 else 0.0)
        P["arm_l"] = P["arm_r"] = 2.9
        P["mouth"] = 1.0
        yaw = 0.4 * math.sin(t * 5)
    elif action == "sad":
        P["squash"] = -0.12
        P["bounce"] = 0
        P["arm_l"] = P["arm_r"] = 0.05
        P["mouth"] = 0.0
        P["look"] = (0, -0.8)
        P["lean"] = 0.3 * math.sin(t * 1.2)
        P["eyes"] = 0.85
    elif action == "talk":
        P["mouth"] = 0.15 + 0.7 * (0.5 + 0.5 * math.sin(t * 15))
        P["arm_r"] = 1.2 + 0.5 * math.sin(t * 3.0)
        P["bounce"] = 0.05 * abs(math.sin(t * 3.5))
        yaw = 0.15 * math.sin(t * 1.5)
    elif action == "point":
        P["arm_r"] = 1.45
        P["mouth"] = 0.4
        P["look"] = (0.8, 0.1)
        yaw = -0.35
    elif action == "sneak":
        P["walk"] = t * 5.0
        P["squash"] = -0.15
        P["look"] = (-0.8, 0)
        P["eyes"] = 1.2
        dx = lerp(x0, x1, u) - x0
        yaw = 0.9 if x1 >= x0 else -0.9
    # "idle" falls through to defaults
    return P, dx, dz, yaw


# ---------------------------------------------------------------- renderer
_RAY_CACHE = {}


def _rays(cam, W, H):
    eye = np.array(cam["eye"], np.float32)
    tgt = np.array(cam["target"], np.float32)
    fov = float(cam.get("fov", 40))
    key = (tuple(eye.round(4)), tuple(tgt.round(4)), fov, W, H)
    if key in _RAY_CACHE:
        return _RAY_CACHE[key]
    f = tgt - eye
    f /= np.linalg.norm(f)
    r = np.cross(f, np.array([0, 1, 0], np.float32))
    r /= np.linalg.norm(r)
    u = np.cross(r, f)
    tanf = math.tan(math.radians(fov) / 2)
    asp = W / H
    xs = ((np.arange(W, dtype=np.float32) + 0.5) / W * 2 - 1) * asp * tanf
    ys = (1 - (np.arange(H, dtype=np.float32) + 0.5) / H * 2) * tanf
    px, py = np.meshgrid(xs, ys)
    d = f[None, None, :] + px[..., None] * r + py[..., None] * u
    d /= np.linalg.norm(d, axis=2, keepdims=True)
    if len(_RAY_CACHE) > 4:
        _RAY_CACHE.clear()
    res = (eye, f, r, u, tanf, asp, d.astype(np.float32))
    _RAY_CACHE[key] = res
    return res


def render(ells, cam, W, H, env="day"):
    e = ENVS[env] if isinstance(env, str) else env
    top, bot = hex2rgb(e["top"]), hex2rgb(e["bot"])
    ga, gb = hex2rgb(e["ga"]), hex2rgb(e["gb"])
    eye, f, r, u, tanf, asp, d = _rays(cam, W, H)

    tbest = np.full((H, W), np.inf, np.float32)
    idb = np.full((H, W), -2, np.int32)

    dy = d[..., 1]
    with np.errstate(divide="ignore", invalid="ignore"):
        tg = -eye[1] / dy
    mg = (dy < -1e-4) & (tg > 0)
    tbest = np.where(mg, tg, tbest)
    idb = np.where(mg, -1, idb)

    for i, el in enumerate(ells):
        v = el.c - eye
        z = float(v @ f)
        mr = float(el.r.max())
        if z <= mr + 0.05:
            y0, y1, x0, x1 = 0, H, 0, W
        else:
            sx = float(v @ r) / z / (tanf * asp)
            sy = float(v @ u) / z / tanf
            rr = mr / (z - mr) / tanf * 1.12
            x0 = max(0, int((sx - rr / asp + 1) / 2 * W) - 1)
            x1 = min(W, int((sx + rr / asp + 1) / 2 * W) + 2)
            y0 = max(0, int((1 - (sy + rr)) / 2 * H) - 1)
            y1 = min(H, int((1 - (sy - rr)) / 2 * H) + 2)
            if x0 >= x1 or y0 >= y1:
                continue
        ds = d[y0:y1, x0:x1] / el.r
        o = (eye - el.c) / el.r
        a = np.einsum("hwc,hwc->hw", ds, ds)
        b = ds @ o
        c = float(o @ o) - 1.0
        disc = b * b - a * c
        hit = disc > 0
        t = (-b - np.sqrt(np.where(hit, disc, 0))) / a
        tb = tbest[y0:y1, x0:x1]
        hit &= (t > 0.01) & (t < tb)
        tbest[y0:y1, x0:x1] = np.where(hit, t, tb)
        idb[y0:y1, x0:x1] = np.where(hit, i, idb[y0:y1, x0:x1])

    # background gradient
    gy = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    img = (top * (1 - gy) + bot * gy) * np.ones((1, W, 1), np.float32)

    finite = np.isfinite(tbest)
    tb = np.where(finite, tbest, 0.0)
    P = eye + d * tb[..., None]

    # ground
    gm = idb == -1
    if gm.any():
        gx, gz = P[..., 0][gm], P[..., 2][gm]
        chk = ((np.floor(gx * 0.7) + np.floor(gz * 0.7)) % 2).astype(np.float32)[:, None]
        gcol = ga * (1 - chk) + gb * chk
        sh = np.ones(gx.shape, np.float32)
        for el in ells:
            if not el.shadow:
                continue
            q = ((gx - el.c[0]) / (el.r[0] * 1.15)) ** 2 + ((gz - el.c[2]) / (el.r[2] * 1.15)) ** 2
            hgt = max(0.0, float(el.c[1] - el.r[1]))
            att = 1.0 / (1.0 + hgt * 1.6)
            sh *= 1 - 0.38 * att * np.exp(-q * 1.3)
        gcol = gcol * sh[:, None]
        fog = 1 - np.exp(-tb[gm] * 0.045)
        fogc = bot[None, :]
        gcol = gcol * (1 - fog[:, None]) + fogc * fog[:, None]
        img[gm] = gcol

    # objects
    L = np.array([0.45, 0.85, 0.55], np.float32)
    L /= np.linalg.norm(L)
    for i in np.unique(idb[idb >= 0]):
        el = ells[int(i)]
        m = idb == i
        n = (P[m] - el.c) / (el.r ** 2)
        n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-8
        lam = n @ L
        band = np.where(lam > 0.55, 1.0, np.where(lam > 0.05, 0.80, 0.60)).astype(np.float32)
        col = el.col[None, :] * band[:, None]
        view = -d[m]
        rim = 1 - np.clip(np.einsum("ij,ij->i", n, view), 0, 1)
        col = col + (rim > 0.72)[:, None] * 0.10
        hv = L[None, :] + view
        hv /= np.linalg.norm(hv, axis=1, keepdims=True) + 1e-8
        spec = np.einsum("ij,ij->i", n, hv) > 0.975
        col = col + spec[:, None] * 0.35
        if el.glow:
            col = col + el.glow * 0.5
        img[m] = col

    # ink outline from id buffer
    a = idb
    ex = np.zeros((H, W), bool)
    ex[:, 1:] |= (a[:, 1:] != a[:, :-1]) & ((a[:, 1:] >= 0) | (a[:, :-1] >= 0))
    ex[1:, :] |= (a[1:, :] != a[:-1, :]) & ((a[1:, :] >= 0) | (a[:-1, :] >= 0))
    th = max(1, int(round(W / 330)))
    ex = cv2.dilate(ex.astype(np.uint8), np.ones((th, th), np.uint8)) > 0
    img[ex] = np.array([0.10, 0.06, 0.16], np.float32)

    out = (np.clip(img, 0, 1) * 255).astype(np.uint8)
    return out[..., ::-1].copy()  # RGB -> BGR for cv2/ffmpeg
