#!/usr/bin/env python3
"""
qc_check.py - automatic quality gate for the finished short.

usage: qc_check.py final.mp4 [--json]
exit code 0 = all PASS, 1 = something FAILED (see FIX hints)
Checks: 9:16 1080x1920, duration 12-60s, audio present, loudness about -14 LUFS,
long silences, black frames, file size, fps.
"""
import json
import re
import subprocess
import sys


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.stdout + p.stderr


def probe(path):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
        capture_output=True, text=True).stdout
    return json.loads(out)


def main():
    path = sys.argv[1]
    info = probe(path)
    v = next((s for s in info["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
    dur = float(info["format"]["duration"])
    size_mb = int(info["format"]["size"]) / 1e6
    res = []

    def chk(name, ok, detail, fix=""):
        res.append(dict(name=name, ok=bool(ok), detail=detail, fix=fix))

    chk("video stream", v is not None, "found" if v else "missing", "re-run build_video.py")
    if v:
        w, h = int(v["width"]), int(v["height"])
        chk("size 1080x1920", (w, h) == (1080, 1920), f"{w}x{h}", "scale to 1080x1920")
        num, den = v["r_frame_rate"].split("/")
        fps = float(num) / float(den)
        chk("fps 24-60", 23 <= fps <= 60, f"{fps:.1f}", "set --fps 30")
    chk("duration 12-60s", 12 <= dur <= 60, f"{dur:.1f}s", "trim/extend scenes (best 20-40s)")
    chk("audio present", a is not None, "yes" if a else "no", "add make_audio.py output")
    chk("size < 100MB", size_mb < 100, f"{size_mb:.1f}MB", "raise CRF to 24")

    if a:
        o = run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"])
        m = re.findall(r"I:\s+(-?\d+\.\d+) LUFS", o)
        if m:
            lufs = float(m[-1])
            chk("loudness -16..-12 LUFS", -16.5 <= lufs <= -11.5, f"{lufs:.1f} LUFS", "re-run loudnorm I=-14")
        o = run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-af",
                 "silencedetect=n=-50dB:d=1.2", "-f", "null", "-"])
        sil = re.findall(r"silence_duration: (\d+\.\d+)", o)
        chk("no silence > 1.2s", len(sil) == 0, f"{len(sil)} gaps", "add music/SFX in the gap")

    o = run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vf",
             "blackdetect=d=0.4:pix_th=0.06", "-an", "-f", "null", "-"])
    blk = re.findall(r"black_duration:(\d+\.?\d*)", o)
    chk("no black frames", len(blk) == 0, f"{len(blk)} black spans", "fix scene env/camera")

    ok_all = all(r["ok"] for r in res)
    if "--json" in sys.argv:
        print(json.dumps(res, indent=2))
    else:
        for r in res:
            print(("PASS " if r["ok"] else "FAIL ") + r["name"] + " -> " + r["detail"] +
                  ("" if r["ok"] else "   FIX: " + r["fix"]))
        print("QC", "PASSED" if ok_all else "FAILED")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
