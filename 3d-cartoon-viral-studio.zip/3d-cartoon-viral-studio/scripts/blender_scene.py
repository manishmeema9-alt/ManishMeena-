#!/usr/bin/env python3
"""
blender_scene.py - OPTIONAL higher-quality path (needs Blender, NOT available on phone/cloud by default).
NOTE: written for Blender 3.x/4.x but NOT tested in the skill-authoring sandbox (no Blender there).
If it errors, fall back to build_video.py (always works).

usage:
  blender -b -P blender_scene.py -- storyboard.json OUT_DIR [--res 1080x1920] [--fps 30]
Renders PNG frames to OUT_DIR/frames/, then run:
  ffmpeg -framerate 30 -i OUT_DIR/frames/%05d.png -c:v libx264 -pix_fmt yuv420p silent.mp4
and mux captions/audio with the same ffmpeg steps build_video.py uses (see references/02-3d-pipeline.md).
"""
import json
import math
import os
import sys

import bpy  # noqa

argv = sys.argv[sys.argv.index("--") + 1:]
sb = json.load(open(argv[0], encoding="utf-8"))
out = argv[1]
RES = (1080, 1920)
FPS = sb.get("fps", 30)
if "--res" in argv:
    RES = tuple(int(x) for x in argv[argv.index("--res") + 1].split("x"))

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.engine = "BLENDER_EEVEE_NEXT" if hasattr(bpy.types, "SceneEEVEE") and bpy.app.version >= (4, 2, 0) else "BLENDER_EEVEE"
sc.render.resolution_x, sc.render.resolution_y = RES
sc.render.fps = FPS
sc.render.use_freestyle = True  # ink outlines
sc.render.line_thickness = 1.6
os.makedirs(os.path.join(out, "frames"), exist_ok=True)
sc.render.filepath = os.path.join(out, "frames", "")
sc.render.image_settings.file_format = "PNG"

world = bpy.data.worlds.new("w")
sc.world = world
world.use_nodes = True


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (1,)


def toon_mat(name, color):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out_n = nt.nodes.new("ShaderNodeOutputMaterial")
    diff = nt.nodes.new("ShaderNodeBsdfDiffuse")
    s2r = nt.nodes.new("ShaderNodeShaderToRGB")
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.interpolation = "CONSTANT"
    ramp.color_ramp.elements[0].position = 0.0
    ramp.color_ramp.elements[0].color = (0.6, 0.6, 0.6, 1)
    e = ramp.color_ramp.elements.new(0.45)
    e.color = (0.85, 0.85, 0.85, 1)
    e2 = ramp.color_ramp.elements.new(0.7)
    e2.color = (1, 1, 1, 1)
    mix = nt.nodes.new("ShaderNodeMixRGB")
    mix.blend_type = "MULTIPLY"
    mix.inputs[0].default_value = 1
    mix.inputs[2].default_value = color
    diff.inputs[0].default_value = (1, 1, 1, 1)
    nt.links.new(diff.outputs[0], s2r.inputs[0])
    nt.links.new(s2r.outputs[0], ramp.inputs[0])
    nt.links.new(ramp.outputs[0], mix.inputs[1])
    emit = nt.nodes.new("ShaderNodeEmission")
    nt.links.new(mix.outputs[0], emit.inputs[0])
    nt.links.new(emit.outputs[0], out_n.inputs[0])
    return m


def sphere(name, loc, scale, color):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, location=loc)
    o = bpy.context.active_object
    o.name = name
    o.scale = scale
    bpy.ops.object.shade_smooth()
    o.data.materials.append(toon_mat(name, hexrgb(color)))
    return o


# ground + light
bpy.ops.mesh.primitive_plane_add(size=80, location=(0, 0, 0))
bpy.context.active_object.data.materials.append(toon_mat("ground", hexrgb("#8be36a")))
bpy.ops.object.light_add(type="SUN", location=(4, -6, 8))

cam_data = bpy.data.cameras.new("cam")
cam = bpy.data.objects.new("cam", cam_data)
sc.collection.objects.link(cam)
sc.camera = cam

frame = 1
chars = {}
for cid, c in sb.get("characters", {}).items():
    body = sphere(cid + "_body", (0, 0, 0.72), (0.58, 0.52, 0.62), c.get("color", "#ff8a3d"))
    head = sphere(cid + "_head", (0, 0, 1.62), (0.66, 0.6, 0.58), c.get("color", "#ff8a3d"))
    head.parent = body
    for sx in (-1, 1):
        eye = sphere(cid + "_eye", (sx * 0.24, -0.5, 1.7), (0.19, 0.12, 0.23), "#ffffff")
        eye.parent = body
        pup = sphere(cid + "_pup", (sx * 0.24, -0.58, 1.7), (0.1, 0.06, 0.12), "#1a0f24")
        pup.parent = body
    chars[cid] = body

for sc_i, s in enumerate(sb["scenes"]):
    n = max(1, int(round(s["dur"] * FPS)))
    cc = s.get("cam", {})
    for k, (cid, body) in enumerate(chars.items()):
        act = next((a for a in s.get("actors", []) if a["id"] == cid), None)
        body.hide_render = act is None
        if act:
            body.location.x = act.get("x", 0)
    for f in range(n):
        u = f / max(1, n - 1)
        sc.frame_set(frame)
        orbit = cc.get("orbit", [0, 0])
        dist = cc.get("dist", [9.5, 8.6])
        height = cc.get("height", [2.4, 2.2])
        o = math.radians(orbit[0] + (orbit[1] - orbit[0]) * u)
        d = dist[0] + (dist[1] - dist[0]) * u
        h = height[0] + (height[1] - height[0]) * u
        cam.location = (d * math.sin(o), -d * math.cos(o), h)
        direction = cam.location.copy()
        tgt = type(direction)((0, 0, 1.15))
        look = tgt - direction
        cam.rotation_euler = look.to_track_quat("-Z", "Y").to_euler()
        for act in s.get("actors", []):
            b = chars[act["id"]]
            t = f / FPS
            b.location.z = 0.0 + 0.25 * abs(math.sin(t * 6)) if act.get("action") in ("dance", "bounce", "celebrate") else 0.03 * math.sin(t * 2.4)
        sc.render.filepath = os.path.join(out, "frames", f"{frame:05d}.png")
        bpy.ops.render.render(write_still=True)
        frame += 1
print("frames done:", frame - 1)
